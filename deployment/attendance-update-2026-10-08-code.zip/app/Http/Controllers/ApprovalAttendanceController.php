<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ApprovalAttendanceController extends Controller
{
    public function index()
    {
        // Hanya ambil yang PENDING
        $pendingAttendances = Attendance::with(['user', 'shift', 'location'])
            ->where('approval_status', 'PENDING')
            ->orderBy('created_at', 'desc')
            ->get();

        return view('hr.approval_attendance.index', compact('pendingAttendances'));
    }

    public function approve(Request $request, Attendance $attendance)
    {
        $user = Auth::user();
        if (! ($user && $user->isHR())) {
            return redirect()->back()->with('error', 'Anda tidak berhak menyetujui absensi ini.');
        }

        if ($attendance->approval_status !== 'PENDING') {
            return back()->with('error', 'Absensi ini tidak dalam status menunggu.');
        }

        $updated = Attendance::query()
            ->whereKey($attendance)
            ->where('approval_status', 'PENDING')
            ->update([
                'approval_status' => 'APPROVED',
                'approved_by' => $user->id,
            ]);

        if ($updated === 0) {
            return back()->with('error', 'Absensi ini tidak dalam status menunggu.');
        }

        return back()->with('success', 'Absensi berhasil disetujui.');
    }

    public function reject(Request $request, Attendance $attendance)
    {
        $user = Auth::user();
        if (! ($user && $user->isHR())) {
            return redirect()->back()->with('error', 'Anda tidak berhak menolak absensi ini.');
        }

        if ($attendance->approval_status !== 'PENDING') {
            return back()->with('error', 'Absensi ini tidak dalam status menunggu.');
        }

        $request->validate([
            'rejection_note' => 'required|string|max:255',
        ]);

        $updated = Attendance::query()
            ->whereKey($attendance)
            ->where('approval_status', 'PENDING')
            ->update([
                'approval_status' => 'REJECTED',
                'rejection_note' => $request->rejection_note,
                'approved_by' => $user->id,
                'status' => 'REJECTED',
            ]);

        if ($updated === 0) {
            return back()->with('error', 'Absensi ini tidak dalam status menunggu.');
        }

        return back()->with('success', 'Absensi ditolak.');
    }
}
