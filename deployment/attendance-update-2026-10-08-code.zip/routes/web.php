<?php

use App\Http\Controllers\ApprovalAttendanceController;
use App\Http\Controllers\ApprovalController;
use App\Http\Controllers\Atk\Admin\AccessController as AtkAdminAccessController;
use App\Http\Controllers\Atk\Admin\ItemController as AtkAdminItemController;
use App\Http\Controllers\Atk\Admin\NeedRequestController as AtkAdminNeedRequestController;
use App\Http\Controllers\Atk\Admin\ReportController as AtkAdminReportController;
use App\Http\Controllers\Atk\Admin\RequestApprovalController as AtkAdminRequestApprovalController;
use App\Http\Controllers\Atk\Admin\StockController as AtkAdminStockController;
use App\Http\Controllers\Atk\Admin\StockMovementController as AtkAdminStockMovementController;
use App\Http\Controllers\Atk\CartController as AtkCartController;
use App\Http\Controllers\Atk\CatalogController as AtkCatalogController;
use App\Http\Controllers\Atk\NeedRequestController as AtkNeedRequestController;
use App\Http\Controllers\Atk\RequestController as AtkRequestController;
use App\Http\Controllers\AtkMks\Admin\AccessController as AtkMksAdminAccessController;
use App\Http\Controllers\AtkMks\Admin\ItemController as AtkMksAdminItemController;
use App\Http\Controllers\AtkMks\Admin\NeedRequestController as AtkMksAdminNeedRequestController;
use App\Http\Controllers\AtkMks\Admin\RequestApprovalController as AtkMksAdminRequestApprovalController;
use App\Http\Controllers\AtkMks\Admin\StockController as AtkMksAdminStockController;
use App\Http\Controllers\AtkMks\Admin\StockMovementController as AtkMksAdminStockMovementController;
use App\Http\Controllers\AtkMks\CartController as AtkMksCartController;
use App\Http\Controllers\AtkMks\CatalogController as AtkMksCatalogController;
use App\Http\Controllers\AtkMks\RequestController as AtkMksRequestController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\EmployeeDocumentController;
use App\Http\Controllers\EmployeeLoanRequestController;
use App\Http\Controllers\EmployeeShiftController;
use App\Http\Controllers\HR\AssetController;
use App\Http\Controllers\HR\AttendanceLocationController;
use App\Http\Controllers\HR\DivisionController;
use App\Http\Controllers\HR\OfficeHolidayController;
use App\Http\Controllers\HR\OrganizationController;
use App\Http\Controllers\Hr\PayslipController;
use App\Http\Controllers\HR\PositionController;
use App\Http\Controllers\HR\ScheduleController;
use App\Http\Controllers\HRApproverMappingController;
use App\Http\Controllers\HRAttendanceController;
use App\Http\Controllers\HREmployeeController;
use App\Http\Controllers\HrLeaveController;
use App\Http\Controllers\HrLoanRequestController;
use App\Http\Controllers\HrOvertimeController;
use App\Http\Controllers\LeaveRequestController;
use App\Http\Controllers\Ops\Admin\AccessController as OpsAdminAccessController;
use App\Http\Controllers\Ops\Admin\ItemController as OpsAdminItemController;
use App\Http\Controllers\Ops\Admin\NeedRequestController as OpsAdminNeedRequestController;
use App\Http\Controllers\Ops\Admin\RequestApprovalController as OpsAdminRequestApprovalController;
use App\Http\Controllers\Ops\Admin\StockController as OpsAdminStockController;
use App\Http\Controllers\Ops\Admin\StockMovementController as OpsAdminStockMovementController;
use App\Http\Controllers\Ops\CartController as OpsCartController;
use App\Http\Controllers\Ops\CatalogController as OpsCatalogController;
use App\Http\Controllers\Ops\RequestController as OpsRequestController;
use App\Http\Controllers\OvertimeRequestController;
use App\Http\Controllers\PtController;
use App\Http\Controllers\ShiftController;
use App\Http\Controllers\SupervisorDataController;
use App\Http\Controllers\SupervisorOvertimeController;
use App\Http\Controllers\V2AccessController;
use App\Models\Asset;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
});

Route::middleware('auth')->group(function () {

    Route::prefix('v2')->name('v2.')->group(function () {
        Route::get('/access', V2AccessController::class)->name('access');
        Route::middleware('atk-mks.access')->prefix('atk-mks')->name('atk-mks.')->group(function () {
            Route::get('/', [AtkMksCatalogController::class, 'index'])->name('catalog');
            Route::post('/cart', [AtkMksCatalogController::class, 'addToCart'])->name('cart.add');
            Route::get('/cart', [AtkMksCartController::class, 'show'])->name('cart.show');
            Route::put('/cart/{item}', [AtkMksCartController::class, 'update'])->name('cart.update');
            Route::delete('/cart/{item}', [AtkMksCartController::class, 'remove'])->name('cart.remove');
            Route::post('/cart/submit', [AtkMksCartController::class, 'store'])->name('cart.submit');
            Route::get('/requests', [AtkMksRequestController::class, 'index'])->name('requests.index');
            Route::get('/requests/{atkRequest}', [AtkMksRequestController::class, 'show'])->name('requests.show');

            Route::middleware('atk-mks.admin')->prefix('admin')->name('admin.')->group(function () {
                Route::get('/need-requests', [AtkMksAdminNeedRequestController::class, 'index'])->name('need-requests.index');
                Route::get('/need-requests/create', [AtkMksAdminNeedRequestController::class, 'create'])->name('need-requests.create');
                Route::post('/need-requests', [AtkMksAdminNeedRequestController::class, 'store'])->name('need-requests.store');
                Route::get('/requests', [AtkMksAdminRequestApprovalController::class, 'index'])->name('requests.index');
                Route::get('/requests/manual/create', [AtkMksAdminRequestApprovalController::class, 'createManual'])->name('requests.manual.create');
                Route::post('/requests/manual', [AtkMksAdminRequestApprovalController::class, 'storeManual'])->name('requests.manual.store');
                Route::get('/requests/{atkRequest}', [AtkMksAdminRequestApprovalController::class, 'show'])->name('requests.show');
                Route::post('/requests/{atkRequest}/approve-all', [AtkMksAdminRequestApprovalController::class, 'approveAll'])->name('requests.approve-all');
                Route::post('/requests/{atkRequest}/reject', [AtkMksAdminRequestApprovalController::class, 'reject'])->name('requests.reject');
                Route::post('/requests/{atkRequest}/items/{requestItem}/review', [AtkMksAdminRequestApprovalController::class, 'reviewItem'])->name('requests.items.review');
                Route::post('/requests/{atkRequest}/finalize', [AtkMksAdminRequestApprovalController::class, 'finalize'])->name('requests.finalize');
                Route::get('/items', [AtkMksAdminItemController::class, 'index'])->name('items.index');
                Route::get('/items/create', [AtkMksAdminItemController::class, 'create'])->name('items.create');
                Route::post('/items', [AtkMksAdminItemController::class, 'store'])->name('items.store');
                Route::get('/items/{item}/edit', [AtkMksAdminItemController::class, 'edit'])->name('items.edit');
                Route::put('/items/{item}', [AtkMksAdminItemController::class, 'update'])->name('items.update');
                Route::delete('/items/{item}', [AtkMksAdminItemController::class, 'destroy'])->name('items.destroy');
                Route::post('/items/{item}/stock', [AtkMksAdminStockController::class, 'store'])->name('items.stock.store');
                Route::get('/stock-movements', [AtkMksAdminStockMovementController::class, 'index'])->name('stock-movements.index');
                Route::get('/access', [AtkMksAdminAccessController::class, 'index'])->name('access.index');
                Route::post('/access/pts', [AtkMksAdminAccessController::class, 'syncPts'])->name('access.pts.sync');
                Route::post('/access/{user}/grant-admin', [AtkMksAdminAccessController::class, 'grantAdmin'])->name('access.grant-admin');
                Route::delete('/access/{user}/revoke-admin', [AtkMksAdminAccessController::class, 'revokeAdmin'])->name('access.revoke-admin');
            });
        });
        Route::middleware('ops.access')->prefix('ops')->name('ops.')->group(function () {
            Route::get('/', [OpsCatalogController::class, 'index'])->name('catalog');
            Route::post('/cart', [OpsCatalogController::class, 'addToCart'])->name('cart.add');
            Route::get('/cart', [OpsCartController::class, 'show'])->name('cart.show');
            Route::put('/cart/{item}', [OpsCartController::class, 'update'])->name('cart.update');
            Route::delete('/cart/{item}', [OpsCartController::class, 'remove'])->name('cart.remove');
            Route::post('/cart/submit', [OpsCartController::class, 'store'])->name('cart.submit');
            Route::get('/requests', [OpsRequestController::class, 'index'])->name('requests.index');
            Route::get('/requests/{atkRequest}', [OpsRequestController::class, 'show'])->name('requests.show');

            Route::middleware('ops.admin')->prefix('admin')->name('admin.')->group(function () {
                Route::get('/need-requests', [OpsAdminNeedRequestController::class, 'index'])->name('need-requests.index');
                Route::get('/need-requests/create', [OpsAdminNeedRequestController::class, 'create'])->name('need-requests.create');
                Route::post('/need-requests', [OpsAdminNeedRequestController::class, 'store'])->name('need-requests.store');
                Route::get('/requests', [OpsAdminRequestApprovalController::class, 'index'])->name('requests.index');
                Route::get('/requests/manual/create', [OpsAdminRequestApprovalController::class, 'createManual'])->name('requests.manual.create');
                Route::post('/requests/manual', [OpsAdminRequestApprovalController::class, 'storeManual'])->name('requests.manual.store');
                Route::get('/requests/{atkRequest}', [OpsAdminRequestApprovalController::class, 'show'])->name('requests.show');
                Route::post('/requests/{atkRequest}/approve-all', [OpsAdminRequestApprovalController::class, 'approveAll'])->name('requests.approve-all');
                Route::post('/requests/{atkRequest}/reject', [OpsAdminRequestApprovalController::class, 'reject'])->name('requests.reject');
                Route::post('/requests/{atkRequest}/items/{requestItem}/review', [OpsAdminRequestApprovalController::class, 'reviewItem'])->name('requests.items.review');
                Route::post('/requests/{atkRequest}/finalize', [OpsAdminRequestApprovalController::class, 'finalize'])->name('requests.finalize');
                Route::get('/items', [OpsAdminItemController::class, 'index'])->name('items.index');
                Route::get('/items/create', [OpsAdminItemController::class, 'create'])->name('items.create');
                Route::post('/items', [OpsAdminItemController::class, 'store'])->name('items.store');
                Route::get('/items/{item}/edit', [OpsAdminItemController::class, 'edit'])->name('items.edit');
                Route::put('/items/{item}', [OpsAdminItemController::class, 'update'])->name('items.update');
                Route::delete('/items/{item}', [OpsAdminItemController::class, 'destroy'])->name('items.destroy');
                Route::post('/items/{item}/stock', [OpsAdminStockController::class, 'store'])->name('items.stock.store');
                Route::get('/stock-movements', [OpsAdminStockMovementController::class, 'index'])->name('stock-movements.index');
                Route::get('/access', [OpsAdminAccessController::class, 'index'])->name('access.index');
                Route::post('/access/divisions', [OpsAdminAccessController::class, 'syncDivisions'])->name('access.divisions.sync');
                Route::post('/access/{user}/grant-admin', [OpsAdminAccessController::class, 'grantAdmin'])->name('access.grant-admin');
                Route::delete('/access/{user}/revoke-admin', [OpsAdminAccessController::class, 'revokeAdmin'])->name('access.revoke-admin');
            });
        });

        Route::prefix('atk')->name('atk.')->group(function () {
            Route::get('/', [AtkCatalogController::class, 'index'])->name('catalog');
            Route::post('/cart', [AtkCatalogController::class, 'addToCart'])->name('cart.add');
            Route::get('/cart', [AtkCartController::class, 'show'])->name('cart.show');
            Route::post('/cart/submit', [AtkCartController::class, 'store'])->name('cart.submit');
            Route::put('/cart/{item}', [AtkCartController::class, 'update'])->name('cart.update');
            Route::delete('/cart/{item}', [AtkCartController::class, 'remove'])->name('cart.remove');
            Route::get('/requests', [AtkRequestController::class, 'index'])->name('requests.index');
            Route::get('/requests/{atkRequest}', [AtkRequestController::class, 'show'])->name('requests.show');
            Route::get('/need-requests', [AtkNeedRequestController::class, 'index'])->name('need-requests.index');
            Route::get('/need-requests/create', [AtkNeedRequestController::class, 'create'])->name('need-requests.create');
            Route::post('/need-requests', [AtkNeedRequestController::class, 'store'])->name('need-requests.store');

            Route::middleware('atk.admin')->prefix('admin')->name('admin.')->group(function () {
                Route::get('/', fn () => redirect()->route('v2.atk.admin.items.index'))->name('dashboard');
                Route::get('/items', [AtkAdminItemController::class, 'index'])->name('items.index');
                Route::get('/items/create', [AtkAdminItemController::class, 'create'])->name('items.create');
                Route::post('/items', [AtkAdminItemController::class, 'store'])->name('items.store');
                Route::get('/items/{item}/edit', [AtkAdminItemController::class, 'edit'])->name('items.edit');
                Route::put('/items/{item}', [AtkAdminItemController::class, 'update'])->name('items.update');
                Route::post('/items/{item}/stock', [AtkAdminStockController::class, 'store'])->name('items.stock.store');
                Route::get('/stock-movements', [AtkAdminStockMovementController::class, 'index'])->name('stock-movements.index');
                Route::get('/access', [AtkAdminAccessController::class, 'index'])->name('access.index');
                Route::post('/access/{user}/grant', [AtkAdminAccessController::class, 'grant'])->name('access.grant');
                Route::delete('/access/{user}/revoke', [AtkAdminAccessController::class, 'revoke'])->name('access.revoke');
                Route::get('/requests', [AtkAdminRequestApprovalController::class, 'index'])->name('requests.index');
                Route::get('/requests/manual/create', [AtkAdminRequestApprovalController::class, 'createManual'])->name('requests.manual.create');
                Route::post('/requests/manual', [AtkAdminRequestApprovalController::class, 'storeManual'])->name('requests.manual.store');
                Route::get('/requests/{atkRequest}', [AtkAdminRequestApprovalController::class, 'show'])->name('requests.show');
                Route::post('/requests/{atkRequest}/approve', [AtkAdminRequestApprovalController::class, 'approve'])->name('requests.approve');
                Route::post('/requests/{atkRequest}/reject', [AtkAdminRequestApprovalController::class, 'reject'])->name('requests.reject');
                Route::post('/requests/{atkRequest}/items/{requestItem}/review', [AtkAdminRequestApprovalController::class, 'reviewItem'])->name('requests.items.review');
                Route::post('/requests/{atkRequest}/finalize', [AtkAdminRequestApprovalController::class, 'finalize'])->name('requests.finalize');
                Route::get('/need-requests', [AtkAdminNeedRequestController::class, 'index'])->name('need-requests.index');
                Route::post('/need-requests/{needRequest}/process', [AtkAdminNeedRequestController::class, 'process'])->name('need-requests.process');
                Route::get('/reports', [AtkAdminReportController::class, 'index'])->name('reports.index');
                Route::get('/reports/export', [AtkAdminReportController::class, 'export'])->name('reports.export');
            });
        });
    });

    Route::get('/dashboard', function () {
        $receivedAssets = Asset::with('category')
            ->where('current_user_id', auth()->id())
            ->orderBy('name')
            ->get();

        return view('dashboard', compact('receivedAssets'));
    })->name('dashboard');

    Route::get('/leave-requests/search-substitute', [LeaveRequestController::class, 'searchSubstitute'])
        ->name('leave-requests.search-substitute');

    Route::resource('leave-requests', LeaveRequestController::class)
        ->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);
    Route::get('/leave-requests/{leave_request}/supporting-file', [LeaveRequestController::class, 'supportingFile'])
        ->name('leave-requests.supporting-file');
    Route::post('/leave-requests/{leave_request}/upload-photo', [LeaveRequestController::class, 'uploadPhoto'])
        ->name('leave-requests.upload-photo');
    Route::get('/leave-requests/{leave_request}/attachments/{attachment}', [LeaveRequestController::class, 'attachmentFile'])
        ->name('leave-requests.attachment-file');
    Route::delete('/leave-requests/{leave_request}/attachments/{attachment}', [LeaveRequestController::class, 'destroyAttachment'])
        ->name('leave-requests.attachments.destroy');

    // [BARU] Endpoint untuk cek duplikat pengajuan
    Route::post('/leave-requests/check-duplicate', [LeaveRequestController::class, 'checkDuplicate'])->name('leave-requests.checkDuplicate');
    Route::post('/leave-requests/calculate-effective-days', [LeaveRequestController::class, 'calculateEffectiveDays'])
        ->name('leave-requests.calculate-effective-days');

    Route::resource('overtime-requests', OvertimeRequestController::class)
        ->only(['index', 'create', 'store', 'update', 'destroy']);

    Route::get('/attendance', [AttendanceController::class, 'dashboard'])->name('attendance.dashboard');
    Route::get('/attendance/clock-in', [AttendanceController::class, 'showClockInForm'])->name('attendance.clockIn.form');
    Route::post('/attendance/clock-in', [AttendanceController::class, 'clockIn'])->name('attendance.clockIn');
    Route::get('/attendance/clock-out', [AttendanceController::class, 'showClockOutForm'])->name('attendance.clockOut.form');
    Route::post('/attendance/clock-out', [AttendanceController::class, 'clockOut'])->name('attendance.clockOut');

    // Remote Attendance (Karyawan)
    Route::prefix('remote-attendance')->name('remote-attendance.')->group(function () {
        Route::get('/', [AttendanceController::class, 'remoteIndex'])->name('index');
        Route::get('/purpose', [AttendanceController::class, 'remotePurpose'])->name('purpose');
        Route::get('/photo', [AttendanceController::class, 'remotePhoto'])->name('photo');
        Route::get('/clock-out', [AttendanceController::class, 'showRemoteClockOutForm'])->name('clockOut.form');
        Route::post('/clock-in', [AttendanceController::class, 'remoteClockIn'])->name('clockIn');
        Route::post('/clock-out', [AttendanceController::class, 'remoteClockOut'])->name('clockOut');
    });

    Route::middleware('loan.eligible')->group(function () {
        Route::get('/loan-requests', [EmployeeLoanRequestController::class, 'index'])->name('employee.loan_requests.index');
        Route::get('/loan-requests/create', [EmployeeLoanRequestController::class, 'create'])->name('employee.loan_requests.create');
        Route::post('/loan-requests', [EmployeeLoanRequestController::class, 'store'])->name('employee.loan_requests.store');
        Route::get('/loan-requests/{loan}', [EmployeeLoanRequestController::class, 'show'])->name('employee.loan_requests.show');
        Route::delete('/loan-requests/{loan}', [EmployeeLoanRequestController::class, 'destroy'])->name('employee.loan_requests.destroy');
    });

    Route::get('/settings/password', [AuthController::class, 'showChangePasswordForm'])->name('settings.password');
    Route::put('/settings/password', [AuthController::class, 'updatePassword'])->name('settings.password.update');

    // --- ROUTE HRD & HR STAFF ---
    Route::middleware('role:HRD,HR STAFF')->group(function () {

        Route::get('/hr/leave-requests', [HrLeaveController::class, 'index'])->name('hr.leave.index');
        Route::get('/hr/leave-requests/{leave}', [HrLeaveController::class, 'show'])->name('hr.leave.show');
        Route::put('/hr/leave-requests/{leave}', [HrLeaveController::class, 'update'])->name('hr.leave.update');
        Route::put('/hr/leave-requests/{leave}/adjust-date', [HrLeaveController::class, 'adjustApprovedDate'])->name('hr.leave.adjust-date');
        Route::post('/hr/leave-requests/{leave}/approve', [HrLeaveController::class, 'approve'])->name('hr.leave.approve');
        Route::post('/hr/leave-requests/{leave}/reject', [HrLeaveController::class, 'reject'])->name('hr.leave.reject');

        Route::get('/hr/leave/master', [HrLeaveController::class, 'master'])->name('hr.leave.master');
        Route::get('/hr/leave/master/export', [HrLeaveController::class, 'exportMaster'])->name('hr.leave.master.export');
        Route::get('/hr/leave/master/export-cuti', [HrLeaveController::class, 'exportAnnualLeave'])->name('hr.leave.master.export-cuti');
        Route::get('/hr/leave/master/create', [HrLeaveController::class, 'createManual'])->name('hr.leave.manual.create');
        Route::post('/hr/leave/master/create', [HrLeaveController::class, 'storeManual'])->name('hr.leave.manual.store');

        Route::get('/hr/shifts', [ShiftController::class, 'index'])->name('hr.shifts.index');
        Route::get('/hr/shifts/create', [ShiftController::class, 'create'])->name('hr.shifts.create');
        Route::post('/hr/shifts', [ShiftController::class, 'store'])->name('hr.shifts.store');
        Route::get('/hr/shifts/{shift}/edit', [ShiftController::class, 'edit'])->name('hr.shifts.edit');
        Route::put('/hr/shifts/{shift}', [ShiftController::class, 'update'])->name('hr.shifts.update');
        Route::delete('/hr/shifts/{shift}', [ShiftController::class, 'destroy'])->name('hr.shifts.destroy');

        Route::get('/hr/office-holidays', [OfficeHolidayController::class, 'index'])->name('hr.office-holidays.index');
        Route::post('/hr/office-holidays', [OfficeHolidayController::class, 'store'])->name('hr.office-holidays.store');
        Route::get('/hr/office-holidays/{officeHoliday}/edit', [OfficeHolidayController::class, 'edit'])->name('hr.office-holidays.edit');
        Route::put('/hr/office-holidays/{officeHoliday}', [OfficeHolidayController::class, 'update'])->name('hr.office-holidays.update');
        Route::delete('/hr/office-holidays/{officeHoliday}', [OfficeHolidayController::class, 'destroy'])->name('hr.office-holidays.destroy');

        // --- EMPLOYEE MANAGEMENT ---
        Route::get('/hr/employees', [HREmployeeController::class, 'index'])->name('hr.employees.index');
        Route::get('/hr/employees/create', [HREmployeeController::class, 'create'])->name('hr.employees.create');
        Route::post('/hr/employees', [HREmployeeController::class, 'store'])->name('hr.employees.store');
        Route::get('/hr/approvers', [HRApproverMappingController::class, 'index'])->name('hr.approvers.index');
        Route::get('/hr/approvers/search', [HRApproverMappingController::class, 'searchApprovers'])->name('hr.approvers.search');
        Route::get('/hr/approvers/create', [HRApproverMappingController::class, 'create'])->name('hr.approvers.create');
        Route::post('/hr/approvers', [HRApproverMappingController::class, 'store'])->name('hr.approvers.store');
        Route::get('/hr/approvers/{approver}/users/search', [HRApproverMappingController::class, 'searchUsers'])->name('hr.approvers.users.search');
        Route::get('/hr/approvers/{approver}/users/create', [HRApproverMappingController::class, 'createUser'])->name('hr.approvers.users.create');
        Route::post('/hr/approvers/{approver}/users', [HRApproverMappingController::class, 'storeUser'])->name('hr.approvers.users.store');
        Route::delete('/hr/approvers/{approver}/users/{user}', [HRApproverMappingController::class, 'destroyUser'])->name('hr.approvers.users.destroy');
        Route::patch('/hr/approvers/{approver}/revoke', [HRApproverMappingController::class, 'revoke'])->name('hr.approvers.revoke');
        Route::get('/hr/approvers/{approver}', [HRApproverMappingController::class, 'show'])->name('hr.approvers.show');
        Route::get('/hr/employees/{employee}', [HREmployeeController::class, 'show'])->name('hr.employees.show');
        Route::get('/hr/employees/{employee}/edit', [HREmployeeController::class, 'edit'])->name('hr.employees.edit');
        Route::put('/hr/employees/{employee}', [HREmployeeController::class, 'update'])->name('hr.employees.update');
        Route::patch('/hr/employees/{employee}/reset-password', [HREmployeeController::class, 'resetPassword'])->name('hr.employees.reset-password');
        Route::put('/hr/employees/{employee}/exit', [HREmployeeController::class, 'exit'])->name('hr.employees.exit');
        Route::get('/hr/employees/{employee}/exit-detail', [HREmployeeController::class, 'exitDetail'])->name('hr.employees.exit_detail');
        Route::delete('/hr/employees/{employee}', [HREmployeeController::class, 'destroy'])->name('hr.employees.destroy');

        Route::get('/hr/employees/{user}/shift', [EmployeeShiftController::class, 'edit'])->name('hr.employees.shift.edit');
        Route::put('/hr/employees/{user}/shift', [EmployeeShiftController::class, 'update'])->name('hr.employees.shift.update');
        Route::patch('/hr/employees/{user}/shift-inline', [EmployeeShiftController::class, 'updateInline'])->name('hr.employees.shift.inline');
        Route::post('/hr/employees/{user}/documents', [EmployeeDocumentController::class, 'store'])->name('hr.employees.documents.store');
        Route::delete('/hr/employee-documents/{employeeDocument}', [EmployeeDocumentController::class, 'destroy'])->name('hr.employee_documents.destroy');

        Route::get('/hr/assets', [AssetController::class, 'index'])->name('hr.assets.index');
        Route::get('/hr/assets/create', [AssetController::class, 'create'])->name('hr.assets.create');
        Route::post('/hr/assets', [AssetController::class, 'store'])->name('hr.assets.store');
        Route::get('/hr/assets/{asset}/edit', [AssetController::class, 'edit'])->name('hr.assets.edit');
        Route::put('/hr/assets/{asset}', [AssetController::class, 'update'])->name('hr.assets.update');
        Route::get('/hr/assets/{asset}', [AssetController::class, 'show'])->name('hr.assets.show');
        Route::post('/hr/assets/{asset}/movements', [AssetController::class, 'storeMovement'])->name('hr.assets.movements.store');

        Route::prefix('hr/supervisors')->name('hr.supervisors.')->group(function () {
            Route::get('/', [SupervisorDataController::class, 'index'])->name('index');
            Route::get('/create', [SupervisorDataController::class, 'create'])->name('create');
            Route::post('/', [SupervisorDataController::class, 'store'])->name('store');
            Route::get('/{user}', [SupervisorDataController::class, 'show'])->name('show');
            Route::patch('/{user}/off-spv-periods/{period}', [SupervisorDataController::class, 'updateOffSpvPeriod'])
                ->name('off-spv-periods.update');
            Route::post('/{user}/off-spv-history', [SupervisorDataController::class, 'storeHistoricalOffSpv'])
                ->name('off-spv-history.store');
            Route::get('/{user}/edit', [SupervisorDataController::class, 'edit'])->name('edit');
            Route::put('/{user}', [SupervisorDataController::class, 'update'])->name('update');
            Route::delete('/{user}', [SupervisorDataController::class, 'destroy'])->name('destroy');
        });

        Route::get('/hr/locations', [AttendanceLocationController::class, 'index'])->name('hr.locations.index');
        Route::get('/hr/locations/create', [AttendanceLocationController::class, 'create'])->name('hr.locations.create');
        Route::post('/hr/locations', [AttendanceLocationController::class, 'store'])->name('hr.locations.store');
        Route::get('/hr/locations/{location}/edit', [AttendanceLocationController::class, 'edit'])->name('hr.locations.edit');
        Route::put('/hr/locations/{location}', [AttendanceLocationController::class, 'update'])->name('hr.locations.update');
        Route::delete('/hr/locations/{location}', [AttendanceLocationController::class, 'destroy'])->name('hr.locations.destroy');

        Route::get('/hr/schedules', [ScheduleController::class, 'index'])->name('hr.schedules.index');
        Route::post('/hr/schedules', [ScheduleController::class, 'store'])->name('hr.schedules.store');
        Route::get('/hr/schedules/{schedule}/edit', [ScheduleController::class, 'edit'])->name('hr.schedules.edit');
        Route::put('/hr/schedules/{schedule}', [ScheduleController::class, 'update'])->name('hr.schedules.update');
        Route::delete('/hr/schedules/{schedule}', [ScheduleController::class, 'destroy'])->name('hr.schedules.destroy');

        // [UBAH DISINI] MASTER ATTENDANCE (Hanya List)
        Route::get('/hr/attendances', [HRAttendanceController::class, 'index'])->name('hr.attendances.index');

        // APPROVAL ATTENDANCE (WFO dan Dinas Luar)
        Route::get('/hr/approval-attendance', [ApprovalAttendanceController::class, 'index'])->name('hr.approval_attendance.index');
        Route::post('/hr/approval-attendance/{attendance}/approve', [ApprovalAttendanceController::class, 'approve'])->name('hr.approval_attendance.approve');
        Route::post('/hr/approval-attendance/{attendance}/reject', [ApprovalAttendanceController::class, 'reject'])->name('hr.approval_attendance.reject');

        // LOAN REQUESTS (HRD & HR STAFF)
        Route::middleware('role:HRD,HR STAFF')->group(function () {
            Route::get('/hr/loan-requests', [HrLoanRequestController::class, 'index'])->name('hr.loan_requests.index');
            Route::get('/hr/loan-requests/{id}', [HrLoanRequestController::class, 'show'])->name('hr.loan_requests.show');
            Route::get('/hr/loan-requests/{id}/edit', [HrLoanRequestController::class, 'edit'])->name('hr.loan_requests.edit');
            Route::put('/hr/loan-requests/{id}', [HrLoanRequestController::class, 'update'])->name('hr.loan_requests.update');
            Route::post('/hr/loan-requests/{id}/approve', [HrLoanRequestController::class, 'approve'])->name('hr.loan_requests.approve');
            Route::post('/hr/loan-requests/{id}/reject', [HrLoanRequestController::class, 'reject'])->name('hr.loan_requests.reject');
            Route::put('/hr/loan-requests/{id}/internal-note', [HrLoanRequestController::class, 'saveInternalNote'])->name('hr.loan_requests.saveInternalNote');
            Route::post('/hr/loan-requests/{id}/repayments', [HrLoanRequestController::class, 'storeRepayment'])->name('hr.loan_requests.repayments.store');
            Route::put('/hr/loan-requests/{id}/repayments/{repaymentId}', [HrLoanRequestController::class, 'updateRepayment'])->name('hr.loan_requests.repayments.update');
            Route::delete('/hr/loan-requests/{id}/repayments/{repaymentId}', [HrLoanRequestController::class, 'destroyRepayment'])->name('hr.loan_requests.repayments.destroy');
        });

        // Overtime Requests (HR) - Read-only recap flow
        Route::get('/hr/overtime-requests/master', [HrOvertimeController::class, 'master'])->name('hr.overtime-requests.master');
        Route::get('/hr/overtime-requests', [HrOvertimeController::class, 'index'])->name('hr.overtime-requests.index');
        Route::get('/hr/overtime-requests/{overtimeRequest}', [HrOvertimeController::class, 'show'])->name('hr.overtime-requests.show');

        Route::get('/hr/organization', [OrganizationController::class, 'index'])->name('hr.organization');

        Route::get('/hr/positions/create', [PositionController::class, 'create'])->name('hr.positions.create');
        Route::post('/hr/positions', [PositionController::class, 'store'])->name('hr.positions.store');
        Route::get('/hr/positions/{position}/edit', [PositionController::class, 'edit'])->name('hr.positions.edit');
        Route::put('/hr/positions/{position}', [PositionController::class, 'update'])->name('hr.positions.update');
        Route::delete('/hr/positions/{position}', [PositionController::class, 'destroy'])->name('hr.positions.destroy');

        Route::get('/hr/divisions/create', [DivisionController::class, 'create'])->name('hr.divisions.create');
        Route::post('/hr/divisions', [DivisionController::class, 'store'])->name('hr.divisions.store');
        Route::get('/hr/divisions/{division}/edit', [DivisionController::class, 'edit'])->name('hr.divisions.edit');
        Route::put('/hr/divisions/{division}', [DivisionController::class, 'update'])->name('hr.divisions.update');
        Route::delete('/hr/divisions/{division}', [DivisionController::class, 'destroy'])->name('hr.divisions.destroy');

        Route::get('/hr/pts', [PtController::class, 'index'])->name('hr.pts.index');

        Route::get('/hr/pts/create', [PtController::class, 'create'])->name('hr.pts.create');
        Route::post('/hr/pts', [PtController::class, 'store'])->name('hr.pts.store');
        Route::get('/hr/pts/{pt}/edit', [PtController::class, 'edit'])->name('hr.pts.edit');
        Route::put('/hr/pts/{pt}', [PtController::class, 'update'])->name('hr.pts.update');
        Route::delete('/hr/pts/{pt}', [PtController::class, 'destroy'])->name('hr.pts.destroy');
    });

    // PAYSLIP ROUTES (Accessible by HR Manager or any user with can_manage_payroll = true)
    Route::middleware('can:manage-payroll')->group(function () {
        Route::get('/hr/payroll/settings', [PayslipController::class, 'settings'])->name('hr.payroll.settings');
        Route::post('/hr/payroll/settings', [PayslipController::class, 'updateSettings'])->name('hr.payroll.settings.update');

        Route::post('/hr/payroll/import/preview', [PayslipController::class, 'previewImport'])->name('hr.payroll.import.preview');
        Route::post('/hr/payroll/import/store', [PayslipController::class, 'storeBulkImport'])->name('hr.payroll.import.store');
        Route::post('/hr/payroll/export', [PayslipController::class, 'exportExcel'])->name('hr.payroll.export');
        Route::post('/hr/payroll/send-email', [PayslipController::class, 'sendSelectedEmails'])->name('hr.payroll.send-email');
        Route::delete('/hr/payroll/clear-selected', [PayslipController::class, 'destroySelected'])->name('hr.payroll.destroy-selected');

        Route::resource('/hr/payroll', PayslipController::class)
            ->names('hr.payroll')
            ->parameters(['payroll' => 'payslip']);
    });
    Route::middleware('has.subordinates')->prefix('supervisor')->name('supervisor.')->group(function () {
        // Overtime Requests (Supervisor)
        Route::get('/overtime-requests/master', [SupervisorOvertimeController::class, 'master'])->name('overtime-requests.master');
        Route::get('/overtime-requests', [SupervisorOvertimeController::class, 'index'])->name('overtime-requests.index');
        Route::get('/overtime-requests/{overtimeRequest}', [SupervisorOvertimeController::class, 'show'])->name('overtime-requests.show');
        Route::post('/overtime-requests/{overtimeRequest}/approve', [SupervisorOvertimeController::class, 'approve'])->name('overtime-requests.approve');
        Route::post('/overtime-requests/{overtimeRequest}/reject', [SupervisorOvertimeController::class, 'reject'])->name('overtime-requests.reject');
    });

    Route::middleware('leave.approval')->group(function () {
        Route::get('/approval/requests', [ApprovalController::class, 'index'])->name('approval.index');
        Route::get('/supervisor/leave/master', [ApprovalController::class, 'master'])->name('supervisor.leave.master');
        Route::get('/approval/requests/{leave}', [ApprovalController::class, 'show'])->name('approval.show');
        Route::get('/approval/requests/{leave}/edit', [ApprovalController::class, 'edit'])->name('approval.edit');
        Route::put('/approval/requests/{leave}', [ApprovalController::class, 'update'])->name('approval.update');
        Route::delete('/approval/requests/{leave}', [ApprovalController::class, 'destroy'])->name('approval.destroy');
        Route::post('/approval/requests/{leave}/ack', [ApprovalController::class, 'ack'])->name('approval.ack');
        Route::post('/approval/requests/{leave}/approve', [ApprovalController::class, 'approve'])->name('approval.approve');
        Route::post('/approval/requests/{leave}/reject', [ApprovalController::class, 'reject'])->name('approval.reject');
    });

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});

Route::get('/', fn () => redirect()->route('login'));
